//Hira Ijaz
//L19-2377
#define _CRT_SECURE_NO_WARNINGS
#include<iostream>
#include<conio.h>
#include<fstream>
#include<ctime>
#include<iomanip>
#include<string>
#include"POS.h"
#include"helper.h"
using namespace std;


int Item::itemCount = helper::countLine("Items.txt"); //this helper function reads the number of lines in the item file
Item* Item::ItemList = nullptr;
int Customer::customerCount = helper::countLine("Customers.txt");
Customer** Customer::CustomerList = nullptr;
int Sales::salesLineItemcount = helper::countLine("SalesLine.txt");
int Sales::salescount=helper::countLine("Sales.txt");
int Sales::_lineNo =0;
int Sales::_id = 0;
Sales* Sales::salesList = nullptr;
SalesLineItem* Sales::salelineList = nullptr;
int Receipt:: receiptCount=helper::countLine("Receipt.txt");
int Receipt::_rno = 0;
Receipt* Receipt::receiptList = nullptr;


int main() {
	pos p;
	p.MainMenue();
}