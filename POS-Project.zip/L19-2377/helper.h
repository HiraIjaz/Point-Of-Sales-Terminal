//Hira Ijaz
//L19-2377
#pragma once
#define _CRT_SECURE_NO_WARNINGS
#include<iostream>
#include<fstream>
#include<ctime>
#include<conio.h>
#include<iomanip>
#include<string>
using namespace std;
class helper
{
public:
	static int mystrlen(char* str) {
		if (str != nullptr) {
			int size = 0;
			for (; str[size] != '\0'; size++);
			return size;
		}
		return 0;
	}
	static bool mystrcmp(char* str, char* str1) {
		bool match = true;
		if (mystrlen(str) != mystrlen(str1)) {
			return false;
		}
		else {
			for (int i = 0; i < mystrlen(str1) && match == true; i++) {
				if (str[i] == str1[i]) {
					match = true;
				}
				else match = false;
			}
			if (match == true) {
				return true;
			}
			else
				return false;
		}
	}
	static void mystrcpy(char* destination, char* source) {
		if (source != nullptr) {

			for (int i = 0; i < (int)strlen(source); i++) {
				destination[i] = source[i];
			}
			destination[strlen(source)] = '\0';
		}
	}
	static char* CurrentDate() {
		
		static char currentDate[30];

		time_t t = time(NULL);
		struct tm tm = *localtime(&t);
		sprintf_s(currentDate, "%d-%d-%d", tm.tm_mday, tm.tm_mon + 1, tm.tm_year + 1900);
		
		return currentDate;
	}
	static char *currentTime() {
		static char currenttime[15];
		time_t t = time(NULL);
		struct tm tm = *localtime(&t);
		sprintf_s(currenttime, "%d:%d:%d", tm.tm_hour, tm.tm_min, tm.tm_sec);
		return currenttime;
	}
	static int countLine(const char* filename) {
		char line[1000];
		int count = 0;
		fstream fin(filename);
		if (fin.is_open()) {
			while (!fin.eof())
			{
				fin.getline(line, 1000);
				count++;
			}
			fin.close();
			count--;
		}


		return count;
	}
	

};

