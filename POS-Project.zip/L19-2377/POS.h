//Hira Ijaz
//L19-2377
#define _CRT_SECURE_NO_WARNINGS
#pragma once
class Sales;  //class forward decleration
class SalesLineItem;
class Receipt;

//items class
//filling scheme
//<Item_Sku><description><Price><Avalaibale Quantity><Item_date>
class Item
{
private:
	char* item_sku;
	char* description;
	int price;
	int availableQuantity;
	char* creationDate;
	
	static int itemCount; // this contains the  number of items
public:
	static Item* ItemList;
public:
	Item();
	Item(char*, char*, char*, int, int);
	Item(const Item&);
	Item& operator=(const Item&);
	char* getItem_sku();
	char* getDescription();
	int getPrice();
	int getAvailableQuantity();
	char* getCreationDate();
	void setItem_sku(char* i);
	void setDescription(char*);
	void setPrice(int);
	void setAvailableQuantity(int);
	void setCreationDate(char*);
	static void addItem(); //this function adds a new item to both the file and itemlist
	static void readItem(); //this function reads the data from file into itemlist
	static void deleteItem(); //this deletes an item
	static void modifyItem(); //this changes the details of an item from the resord (both in file and itemlist)
	static void searchItem(); //this searches a desired item from the itemlist
	static void feedItemToFile();
	Item* searchSku(char* buffer,int&);
	void printItem(); //it prints a sigle item
	void printItemList(); //it prints the whole record of items
	~Item();
};
//Customer class
//filling scheme
//<Cnic><Name><Address><Phone_no><Email><Type><Amount_PayAble><Saleslimit>

class Customer
{
protected:
	char* cnic;
	char* name;
	char* address;
	char* phone;
	char* email;
	int type;
	int salesLimit;
	int amountPayable;
	
	static int customerCount;
public:
	static Customer** CustomerList;

	// will have association with sales class for deletion purpose
public:
	Customer();
	Customer(char*, char*, char*, char*, char*, int, int);
	Customer(Customer& obj);
	Customer& operator=(Customer& obj);
	char* getCnic();
	char* getName();
	char* getAddress();
	char* getPhone();
	char* getEmail();
	int getType();
	int getAmountPayable();
	virtual void setsalesLimit(int);
	virtual int getsalesLimit();
	void setCnic(char*);
	void setName(char*);
	void setAddress(char*);
	void setPhone(char*);
	void setEmail(char*);
	void setType(int);
	void setAmountPayable(int);
	static void addCustomer();
	static void readCustomers();
	static void deleteCustomer();
	static void modifyCustomer();
	static void searchCustomer();
	static void feedCustomerToFile();
	static Customer* searchCnic(char*,int&);
	
	void printCustomer();
	~Customer();
};
class SilverCustomer :public Customer {
public:
	SilverCustomer();
	SilverCustomer(char*, char*, char*, char*, char*, int, int);      //saleslimit will be set to 40,000
	SilverCustomer& operator=(SilverCustomer& obj);
	void setsalesLimit();
	int getsalesLimit();
	~SilverCustomer();
};
class GoldCustomer :public Customer {
private:
	int discount;
public:
	GoldCustomer(); //discount will be set to 3% and sales limit to 100,000
	GoldCustomer(char* c, char* n, char* a, char* p, char* e, int t, int am);
	GoldCustomer& operator=(GoldCustomer& obj);
	void setsalesLimit();
	int getsalesLimit();
	~GoldCustomer();
};
class PlatinumCustomer :public Customer {
private:
	int discount;
public:
	PlatinumCustomer(); //discount will be set to  5% and sales limit to 250,000
	PlatinumCustomer(char* c, char* n, char* a, char* p, char* e, int t, int am);
	PlatinumCustomer& operator=(PlatinumCustomer& obj);
	void setsalesLimit();
	int getsalesLimit();
	~PlatinumCustomer();
};
//sales class
//filling scheme
//<Sales_Id><Cnic><Date><Sales_Amount><Status>
class Sales{
private:
	int salesId;
	static int _id;
	char* date;
	char* status;
	int SalesAmount;
	static int salesLineItemcount;
	static int salescount;
	static int _lineNo;
	Customer* c;
public:
	static Sales* salesList;
	static SalesLineItem* salelineList;
public:
	Sales();
	Sales(char*,char*,char*,int,int);
	Sales(Sales&);
	Sales &operator= ( Sales&obj);
	 Customer* checkCnic(char*,int&); //used to check wether the entered cnic is valid or nor.
	static void set_ID(int);
	void setSalesAmount(int);
	 void setDate(char*); 
	 void setSalesId(int x);
	void setStatus(char*);
	static int get_ID();
	int getSalesId();
	int getSalesAmount();
	char* getDate();
	char* getCustomerCnic();
	char* getStatus();
	char* getCustomerName();
	static int get_lineNo();
	static void FeedSalesToFile();
	static int CheckSales_Id(int);//checks wether a salesId is valid or not if yes then returns  indexes.
	static int*checkSalesDate(char*,char*,int&);//checks if another sale was made on the desired date and returnsan array of the indexs of salesList of that date.
	static bool CnicExistInSale(char*); //it is used to check wether a customer is assocuated with any sale or not.
	static bool check_ItemSku(char*); //it is used to chexk wether an item is included in a salelineitemlist or not.
	static int searchSalesId(int);
	static void readSalesLineItem();
	static void AddSalesLineitem(char**,int*,int,int,int);
	static void readSales(); //this will read from the Sales.txt file and write data into salesList pointer.
	static void writeSales(char*,char*,char*,int,int,int);//this will write to the Sales.txt file plus append new data to salesList pointer.
	~Sales();
};
//sales Line Item Class
//filling scheme
//<Line_No><Sales_Id><Item_Sku><Quantity>

class SalesLineItem{
private:
	int lineNo;
	char *itemOfSale;
	int Quantity;
public:
	Sales saleid;


public:
	SalesLineItem();
	SalesLineItem(int,int,char*,int);
	SalesLineItem& operator=( SalesLineItem&);
	SalesLineItem(SalesLineItem&);
	void setLineNo(int);
	int getLineNo();
	void setQuantity(int);
	int getQuantity();
	char* getItemOfSale_sku();
	void setItemOfSale_sku(char*);
	void setItemOfSale_Id(int);
	int getItemOfSale_Id();
	~SalesLineItem();
	
};
//Receipt Class
//filling scheme
//<Receipt_No><date><Sales_Id><Amount_Paid>
class Receipt {
private:
	static int _rno;
	int receiptNo;
	char* receiptDate;
	int amount;
	Sales receiptSaleId;
	static int receiptCount;
public:
	static Receipt* receiptList;
public:
	Receipt();
	Receipt( Receipt&);
	Receipt& operator=( Receipt&);
	 int getReceiptNo();
	 void setReceiptNo(int);
	 void setReceiptSaleId(int);
	void setamount(int);
    int getamount();
	void setReceiptDate(char*);
	char* getReceiptdate();
	int getReceiptSaleId();
	static int get_rno();
	static void set_rno(int);

	static int* checkSalesId_inReceipts(int,int&);
	static void readReceipt(); //this will read from receipts.txt file to receiptList.
	static void writeReceipt(char*,int,int,int); //this will append data to both file and receiptList.
	~Receipt();

};
//pos Class
class pos {
private:
	Item item;
	Customer customer;
	Sales sales;
	Receipt receipt;

public:
	
	void MainMenue();
	void ItemsMenue();
	void CustomersMenue();
	void  MakeSales(); 
	void EnterItem();
	void EndSale(char**,int*,int,int,int,int,char*);
	void MakePayment();



};


