//Hira Ijaz
//L19-2377
#define _CRT_SECURE_NO_WARNINGS
#include<iostream>
#include<conio.h>
#include<fstream>
#include<ctime>
#include<iomanip>
#include<string>
#include"POS.h"
#include"helper.h"

using namespace std;
void pos:: MainMenue(){
	cout << "    *******OOP FINAL PROJECT********" << endl << endl<<endl;
	cout << "    \"Point Of Sale System\"    " << endl << endl;
	cout << "    By: Hira Ijaz" << endl;
	cout << "        L19-2377" << endl << endl<<endl;

	system("pause");
	system("CLS");
	bool end = false;
	int option=0;
	item.readItem();
	customer.readCustomers();
	sales.readSales();
	sales.readSalesLineItem();
	receipt.readReceipt();
	
	while (end != true) {
		
		cout << "************Main Menue************\n\n\n";
		cout << "	1.Manage Items.\n	2.Manage Customers.\n	3.Make New Sale.\n	4.Make Payment.\n	5.Exit\n";
		cout << "Press 1 to 5 To Select An Option:";
		cin >> option;
		cout << endl;
		if (option == 1) {
			system("CLS");
			ItemsMenue();
		}
		else if (option == 2) {
			system("CLS");
			CustomersMenue();
		}
		else if (option == 3) {
			system("CLS");
			MakeSales();
			system("PAUSE");
		}
		else if (option == 4) {
			system("CLS");
			MakePayment();
			system("PAUSE");
		}
		else if (option == 5) {
			system("CLS");
			end = true;
			cout << "\n\n\n\n\n**********Thanks For Shopping here, We Shall Be Waiting For Your Next vist  **********" << endl << endl;
			cout <<setw(50)<< " ./\\ /\\ " << endl;
			cout << setw(50)<< " (>'.'<)" << endl;
			cout << setw(50)<<" ( U U )" << endl;
			cout << endl;
			cout << endl;
			cout << endl;
			system("PAUSE");
		}
		else cout << "Wrong Option selected.\n";
		system("CLS");
	}

}
void pos:: ItemsMenue(){
	int op=0;
	bool stop = false;

	item.readItem();
	while (stop != true) {
		cout << "**********Items Menue**********\n\n\n";
		cout << "\t1.Add New Item.\n\t2.Update Item details.\n\t3.Find Items.\n\t4.Remove an Existing Item.\n\t5.Back To Main Menue.\n";
		cout << "Press 1 to 5 to select an option.\n";
		cin >> op;
		if (op == 1) {
			system("CLS");
			item.addItem();
			system("PAUSE");
		}
		else if (op == 2) {
			system("CLS");
			item.modifyItem();
			system("PAUSE");
		}
		else if (op == 3) {
			system("CLS");
			item.searchItem();
			system("PAUSE");
		}
		else if (op == 4) {
			system("CLS");
			item.deleteItem();
			system("PAUSE");
		}
		else if (op == 5) {
			stop = true;
		}
		else cout << "wrong option selected.\n";
		system("CLS");
	}
	
}
void pos::CustomersMenue() {
	int op = 0;
	bool stop = false;
	
	customer.readCustomers();
	while (stop != true) {
		cout << "**********Customers Menue**********\n\n\n";
		cout << "\t1. Add new Customer.\n\t2. Update Customers Details.\n\t3. Find Customer.\n\t4. Remove Existing Customer\n\t5. Back To Main Menue.\n";
		cout << "Press 1 to 5 to Select Option.\n";
		cin >> op;
		if (op == 1) {
			system("CLS");
			customer.addCustomer();
			system("PAUSE");
		}
		else if (op == 2) {
			system("CLS");
			customer.modifyCustomer();
			system("PAUSE");
		}
		else if (op == 3) {
			system("CLS");
			customer.searchCustomer();
			system("PAUSE");
		}
		else if (op == 4) {
			system("CLS");
			customer.deleteCustomer();
			system("PAUSE");
		}
		else if (op == 5) {
			stop = true;
		}
		else cout << "wrong option selected.\n";
		system("CLS");
	}
}
                                                                    
void  pos::MakeSales() {
	cin.ignore();
	bool exceed = false,remove=false;
	char* salesDate, * salesTime, _cnic[20], choice[2] = "1";
	char** Item_Sku = new char* [1000];
	int size = 1000;
	int* quantity = new int[1000], totalAmounPayable = 0,balance=0,sumBalance=0;
	int rNo = 0, Cindex = -1,itemindex,*salesIndex=nullptr,saledIndexCount=0;
	salesDate = helper::CurrentDate();
	salesTime = helper::currentTime();
	int Id = Sales::get_ID();
	cout << "Sales ID: " << Id << endl;
	cout << "Sales Date: " << salesDate << endl;
	cout << "Sales Time: " << salesTime << endl;
	cout << "Enter Cnic: ";
	cin.getline(_cnic, 20); cout << endl; cin.clear(); cin.sync();
	int itemcount = 0;
	sales.checkCnic(_cnic, Cindex);
	if (Cindex == -1) {
		while (Cindex != -1) {

			cout << "Invalic Cnic Entered\n" << "Please Enter Again \n ";
			cin.getline(_cnic, 20); cout << endl; cin.clear(); cin.sync();
			sales.checkCnic(_cnic, Cindex);
		}
	}
	
	while (choice[0] == '1' ||choice[0]=='3') {
		sumBalance = 0;
		Item_Sku[itemcount] = new char[20];

		cout << "Enter Item Sku: \n";
		cin.getline(Item_Sku[itemcount], 20);
		
		if (item.searchSku(Item_Sku[itemcount], itemindex) != NULL) {
			item = *item.searchSku(Item_Sku[itemcount], itemindex);

			cout << "Description: " << item.getDescription() << endl;
			cout << "Price: " << item.getPrice() << endl;
			cout << "Enter Quantity: ";
			cin >> quantity[itemcount];
			while (item.getAvailableQuantity() < quantity[itemcount]) {
				cout << "Quantity is not valid: \n";
				cout << "Enter Quantity Again:";
				cin >> quantity[itemcount];
				cout << endl;
			}
			balance = balance + item.getPrice() * quantity[itemcount];
			if ((salesIndex = Sales::checkSalesDate(salesDate, _cnic, saledIndexCount)) != nullptr) {//checks if a sales was made on the same date before.
				for (int i = 0; i < saledIndexCount; i++) {
					sumBalance = sumBalance + Sales::salesList[salesIndex[i]].getSalesAmount(); //if yes then previous purchase is added to current purchase.
				}
				sumBalance = sumBalance + balance;
			}
			else {
				sumBalance = balance; //if not the balance remains same.
			}
			if (sumBalance <= Customer::CustomerList[Cindex]->getsalesLimit()) { //checks wether total sale of one days exceeds the sales limit or not.
				totalAmounPayable = balance;

				if (Customer::CustomerList[Cindex]->getType() == 2) {
					totalAmounPayable = totalAmounPayable - ((3 * totalAmounPayable) / 100);
				}
				else if (Customer::CustomerList[Cindex]->getType() == 3) {
					totalAmounPayable = totalAmounPayable - ((5 * totalAmounPayable) / 100);
				}
				cout << "SubTotal" << totalAmounPayable << endl;
				itemcount++;
			}
			else {
				cout << "Your Purchase Has Exceeded Your Sales Limit\n";
				exceed = true;
			}
			cout << "Press 1 to Enter New Item.\n" << "Press 2 to End Sale.\n" << "Press 3 to Remove an Existing Item From Sale.\n" << "Press 4 to Cancel Sale\n";
			cin >> choice;
			if (choice[0] == '3') { //remove the desired item from sale

				int delIndex;
				char buffer[15];
				cout << "Enter The Sku Of Item You Want To Remove:";
				cin >> buffer;

				for (int i = 0, j = 0; i < itemcount; j++, i++) {
					if (helper::mystrcmp(buffer, Item_Sku[i])) { //find the index of the item to be deleted.
						delIndex = i;
						i++;
						remove = true;
					}
				}
				if (remove == true) { //if sku is found that item is removed from sku list
					size--;
					int j = 0, k = 0;
					char** temp = new char* [size];
					int* temp2 = new int[size];
					for (int i = 0; i < itemcount; i++) {
						if (i != delIndex) {
							temp[j] = new char[strlen(Item_Sku[i]) + 1];
							helper::mystrcpy(temp[j++], Item_Sku[i]);
							temp2[k++] = quantity[i];
						}
					}
					for (int i = 0; i < itemcount; i++) {
						delete[] Item_Sku[i];
					}
					delete[] Item_Sku;
					Item_Sku = temp;
					delete[]quantity;
					quantity = temp2;
					itemcount--;
					item = *item.searchSku(buffer, itemindex);  //update total amount after removing the item
					totalAmounPayable = totalAmounPayable - item.getPrice() * quantity[delIndex];
					Item::ItemList[itemindex].setAvailableQuantity(item.getAvailableQuantity() + quantity[delIndex]);//return back item quantity of the removed item
					Item::feedItemToFile();
					cout << "The Item Has Been Successfully removed" << endl << endl;
					cout << "Press 1 to Enter New Item.\n" << "Press 2 to End Sale.\n" << "Press 3 to Remove an Existing Item From Sale.\n" << "Press 4 to Cancel Sale\n";
					cin >> choice;
				}
				else
					cout << "Entered Item Sku Was Wrong\n";


			}
		}
		else cout << "Wrong Sku Entered\n";
		cin.ignore();
	}
	if (choice[0] == '2') {
		if (exceed == true) {
			cout << "As Your Purchase Exceeded The Sales Limit Hence Sales Is Canceled\n";
		}
		else {
			char _status[] = "Pending";
			sales.writeSales(_cnic, salesDate, _status, Id, Cindex, totalAmounPayable);
			sales.AddSalesLineitem(Item_Sku, quantity, Id, Sales::get_lineNo(), itemcount);
			Customer::CustomerList[Cindex]->setAmountPayable((Customer::CustomerList[Cindex]->getAmountPayable()) + totalAmounPayable);//upadtes customer amount payable
			Customer::feedCustomerToFile();
			EndSale(Item_Sku, quantity, itemcount, Cindex, totalAmounPayable, Id, salesDate);
		}
	}
	if (choice[0] == '4') {
		char _status[] = "Canceled";
		sales.writeSales(_cnic, salesDate, _status, Id, Cindex, totalAmounPayable);
	}
	if (salesIndex != nullptr) {
		delete[]salesIndex;
		salesIndex = nullptr;
	}
	Sales::set_ID(Sales::get_ID()+1);
}
void pos::EndSale(char** items,int* quantity,int itemCount,int cindex,int totalSales,int Id,char*salesDate){
	int _index = 0;
	cout << "Sales ID: " << Id << "\t\t\t\t\t\t\t" << "Cnic: " << Customer::CustomerList[cindex]->getCnic() << endl;;
	cout << "Sales Date: " << salesDate << "\t\t\t\t\t" << "Name" << Customer::CustomerList[cindex]->getName()<<endl;
	cout << "Type: ";
	if (Customer::CustomerList[cindex]->getType() == 1) {
		cout << "Silver Customer" << endl;
	}
	else if (Customer::CustomerList[cindex]->getType() == 2) {
		cout << "Gold Customer" << endl;
	}
	else if (Customer::CustomerList[cindex]->getType() == 3) {
		cout << "Platinum Customer" << endl;
	}
	cout << "----------------------------------------------------------------------------------------------------------" << endl;
	cout << "Item_SKU" << "\t\t" << "Description" << "\t\t\t"<< "Quantity" << "\t\t" << "Amount" << endl;
	for (int i = 0; i < itemCount; i++) {
		item = *item.searchSku(items[i], _index);
		cout << Item::ItemList[_index].getItem_sku() << "\t\t\t" << Item::ItemList[_index].getDescription() << "\t\t\t\t" << quantity[i] <<"\t\t" <<Item::ItemList[_index].getPrice() << endl;
	}
	cout << "-------------------------------------------------------------------------------------------------------------" << endl;
	cout << "\t\t\t\t\t\t\t\t\t" << "Total Sales: " << totalSales << endl;

}
void pos::MakePayment(){
	cin.ignore();
	char status[] = "Canceled",completed[]="Completed";
	int Sales_id=0,SalesIndex=0,customerIndex,*salesIdIndexs=nullptr,saledIdIndexCount=0,amountPaid=0,remainingAmount,totalSalesAmount=0,amounToBePaid=0;
	bool validId = false;
	while (validId==false) {
		cout << "Enter Sales ID:";
		cin >> Sales_id;
		if ((SalesIndex = Sales::CheckSales_Id(Sales_id)) == -1){
			cout << "Wrong Sales Id was Enterded Please Enter Correct sales Id.\n";
			cin >> Sales_id;
			cout << endl;
		}
		else if (helper::mystrcmp(Sales::salesList[SalesIndex].getStatus(), status) == true) { //checks wether sales was cancelled or not
			cout << "Sale Has Been Canceled For The Sales Id; " << Sales_id << endl;
			cin >> Sales_id;
			cout << endl;
		}
		else {
			validId = true;
		}
	}
	if (helper::mystrcmp(Sales::salesList[SalesIndex].getStatus(), completed)) { //checks if a sale was already completed
		cout<<"Sales Has Been Completed For the Given Sales Id "<< Sales_id<<"."<<endl;
		
	}
	else {
		customer.searchCnic(Sales::salesList[SalesIndex].getCustomerCnic(), customerIndex);
		cout << "Customer Name: " << Customer::CustomerList[customerIndex]->getName() << endl;
		cout << "Customer Name: " << Customer::CustomerList[customerIndex]->getName() << endl;
		totalSalesAmount = Sales::salesList[SalesIndex].getSalesAmount();
		cout << "Total Sales Amount" << totalSalesAmount << endl;
		if ((salesIdIndexs = Receipt::checkSalesId_inReceipts(Sales_id, saledIdIndexCount)) != nullptr) {
			for (int i = 0; i < saledIdIndexCount; i++) {
				amountPaid = amountPaid + Receipt::receiptList[salesIdIndexs[i]].getamount();
			}
		}
		else amountPaid = 0;
		cout << "Amount Paid: " << amountPaid << endl;
		remainingAmount = totalSalesAmount - amountPaid;
		cout << "Remaining Amount: " << remainingAmount << endl;
		cout << "Enter Amount To Be Paid: ";
		cin >> amounToBePaid;
		cout << endl;
		Customer::CustomerList[customerIndex]->setAmountPayable(Customer::CustomerList[customerIndex]->getAmountPayable() - amounToBePaid);
		Customer::feedCustomerToFile();
		Receipt::writeReceipt(helper::CurrentDate(), Receipt::get_rno(), SalesIndex, amounToBePaid);
		if (remainingAmount - amounToBePaid == 0) { //if all the amount is paid it changes the statuxs from pending to Completed
			char status[] = "Completed";
			Sales::salesList[SalesIndex].setStatus(status);
			Sales::FeedSalesToFile();
		}
	}
	if (salesIdIndexs != nullptr) {
		delete[] salesIdIndexs;
		salesIdIndexs = nullptr;
	}


}