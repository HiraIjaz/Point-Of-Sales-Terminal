//Hira Ijaz
//L19-2377
#define _CRT_SECURE_NO_WARNINGS
#include<iostream>
#include<conio.h>
#include<fstream>
#include<ctime>
#include<iomanip>
#include<string>
#include"POS.h"
#include"helper.h"

using namespace std;
Item::Item() {
	item_sku = nullptr;
	description = nullptr;
	price = 0;
	availableQuantity = 0;
	creationDate = nullptr;

}
Item::Item(char* i, char* d, char* c, int p, int q) {

	setItem_sku(i);
	setDescription(d);
	setCreationDate(c);
	setPrice(p);
	setAvailableQuantity(q);
}
Item& Item:: operator= (const Item& obj) {
	this->item_sku = new char[strlen(obj.item_sku) + 1];
	helper::mystrcpy(this->item_sku, obj.item_sku);
	this->description = new char[strlen(obj.description) + 1];
	helper::mystrcpy(this->description, obj.description);
	this->price = obj.price;
	this->availableQuantity = obj.availableQuantity;
	this->creationDate = new char[strlen(obj.creationDate) + 1];
	helper::mystrcpy(this->creationDate, obj.creationDate);
	return *this;
}
Item::Item(const Item& obj) {
	Item temp;
	temp.item_sku = new char[strlen(obj.item_sku) + 1];
	helper::mystrcpy(temp.item_sku, obj.item_sku);
	description = new char[strlen(obj.description) + 1];
	helper::mystrcpy(temp.description, obj.description);
	temp.price = obj.price;
	temp.price = obj.availableQuantity;
	creationDate = new char[strlen(obj.creationDate) + 1];
	helper::mystrcpy(temp.creationDate, obj.creationDate);

}
char* Item::getItem_sku() {
	return item_sku;
}
char* Item::getDescription() {
	return description;
}
int Item::getPrice() {
	return price;
}
int Item::getAvailableQuantity() {
	return availableQuantity;
}
char* Item::getCreationDate() {
	return creationDate;

}
void Item::setItem_sku(char* i) {
	
	item_sku = new char[strlen(i) + 1];
	helper::mystrcpy(item_sku, i);
}
void Item::setDescription(char* d) {
	
	description = new char[strlen(d) + 1];
	helper::mystrcpy(description, d);

}
void Item::setPrice(int p) {
	price = p;

}
void Item::setAvailableQuantity(int a) {
	availableQuantity = a;

}
void Item::setCreationDate(char* d) {
	
	creationDate = new char[strlen(d) + 1];
	helper::mystrcpy(creationDate, d);
}
void Item::addItem() {
	cin.ignore();
	char _Item_sku[100], _description[1000], * _creationDate;
	int _price, _availableQuantity;
	cout << "Enter the data of new Item: \n";
	cout << " Item SKU: ";
	cin.getline(_Item_sku,100); cout << endl; cin.clear(); cin.sync();
	cout << " Description: ";
	cin.getline(_description,1000); cout << endl; cin.clear(); cin.sync();
	_creationDate = helper::CurrentDate();
	cout << " Price: ";
	cin >> _price; cout << endl; cin.clear(); cin.sync();
	cout << " Avalable Quantity: ";
	cin >> _availableQuantity; cout << endl; cin.clear(); cin.sync();

	Item obj(_Item_sku, _description, _creationDate, _price, _availableQuantity);
	if (Item::itemCount != 0) {
		Item* temp = new Item[Item::itemCount + 1];
		for (int i = 0; i < Item::itemCount; i++) {
			temp[i] = ItemList[i];
		}

		temp[Item::itemCount] = obj;
		ItemList = temp;
		temp = nullptr;
	}
	else { ItemList = new Item(_Item_sku, _description, _creationDate, _price, _availableQuantity); }

	fstream itemfile("Items.txt", ios::app);
	if (itemfile.is_open()) {
		itemfile << obj.item_sku;
		itemfile << ';';
		itemfile << obj.description;
		itemfile << ';';
		itemfile << obj.price;
		itemfile << ';';
		itemfile << obj.availableQuantity;
		itemfile << ';';
		itemfile << obj.creationDate;
		itemfile << '\n';
		Item::itemCount++;
		itemfile.close();
	}
	cout << "Item Has Been Successfully Added!" << endl << endl;
}
void Item::readItem() {
	fstream itemfile("Items.txt");
	char buffer[100];
	int x;

	if (Item::itemCount == 0) {
		ItemList = nullptr;
	}
	else {
		ItemList = new Item[Item::itemCount];
		for (int i = 0; i < Item::itemCount; i++) {
			itemfile.getline(buffer, 10, ';');
			ItemList[i].setItem_sku(buffer);
			itemfile.getline(buffer, 100, ';');
			ItemList[i].setDescription(buffer);
			itemfile >> x;
			ItemList[i].setPrice(x);
			itemfile.ignore(1, ';');
			itemfile >> x;
			ItemList[i].setAvailableQuantity(x);
			itemfile.ignore(1, ';');
			itemfile.getline(buffer, 100, '\n');
			ItemList[i].setCreationDate(buffer);
		}
	}
	itemfile.close();
}
void Item::feedItemToFile() {
	fstream itemfile("Items.txt");
	ofstream tempfile("temp.txt");
	if (itemfile.is_open() && tempfile.is_open())
	{
		int i = 0;
		while (i < Item::itemCount)
		{
			tempfile << ItemList[i].item_sku;
			tempfile << ';';
			tempfile << ItemList[i].description;
			tempfile << ';';
			tempfile << ItemList[i].price;
			tempfile << ';';
			tempfile << ItemList[i].availableQuantity;
			tempfile << ';';
			tempfile << ItemList[i].creationDate;
			tempfile << '\n';
			i++;
		}
		tempfile.close();
		itemfile.close();
		remove("Items.txt");
		int k = rename("temp.txt", "Items.txt");
	}
}
void Item::deleteItem() {
	char buffer[30];
	bool match = false;
	int index = 0;
	cout << "enter the \"item_Sku\" of the item you want to delete:";
	cin.ignore();
	cin.getline(buffer, 30); cout << endl; cin.clear(); cin.sync();
	cout << endl;
	char choice[5];
	
	
		for (int i = 0; i < Item::itemCount && match == false; i++) {
			if (helper::mystrcmp(buffer, ItemList[i].item_sku)) {
				match = true;
				index = i;
			}
		}  
		if (match) {
			if (Sales::check_ItemSku(buffer) == true) {
				cout << "Item Cannot Be Deleted As It Is Included In Sale.\n";
			}
			else {
				cout << "Entered item_Sku matches!!\n";
				cout << "Are you sure want to delete this item?\n";
				cout << "\n------------------------------------------------------------------------------------\n";
				cout << "Item_sku" << setw(20) << "Description" << setw(30) << "Price\t" << setw(20) << "Quantity\n";
				ItemList[index].printItem();
				cout << "If yes,Press \"Enter\" ";
				cin.get(choice, 5); cout << endl; cin.clear(); cin.sync();
				if (choice[0] == '\0') {
					Item::itemCount--;
					Item* temp = new Item[Item::itemCount];
					for (int i = 0, j = 0; i < Item::itemCount; i++, j++) {
						if (j == index) {
							temp[i] = ItemList[j + 1];
							j++;
						}
						else temp[i] = ItemList[j];

					}int count = 0;

					ItemList = temp;
					temp = nullptr;
					feedItemToFile();
					cout << "Item Has Been Successfully Removed!" << endl << endl;

				}
			}
		}
		else {
			cout << "Wrong \"item_sku\"  was entered\n";
		}
	

} 
void Item::modifyItem() {
	char buffer[30];
	bool match = false;
	int index = 0;
	char _item_sku[100], _description[1000], _creationDate[20], _price[100], _avaliableQuantity[100], choice[5];
	cout << "enter the \"item_Sku\" of the item you want to change:";
	cin.ignore();
	cin.getline(buffer, 30); cin.clear(); cin.sync(); cout << endl;
	for (int i = 0; i < Item::itemCount && match == false; i++) {
		if (helper::mystrcmp(buffer, ItemList[i].item_sku)) {
			match = true;
			index = i;
		}
	}
	cout << "Enter Item Details Which You Want to Change:\n";
	cout << "item_sku:";
	cin.getline(_item_sku, 100);
	cout << endl; cin.clear(); cin.sync();
	cout << "Description:";
	cin.getline(_description, 100);
	cout << endl; cin.clear(); cin.sync();
	cout << "Price";
	cin.getline(_price, 100);
	cout << endl; cin.clear(); cin.sync();
	cout << "Available Quantity:";
	cin.getline(_avaliableQuantity, 100);
	cout << endl; cin.clear(); cin.sync();
	cout << "Creation date:";
	cin.getline(_creationDate, 20);
	cout << endl; cin.clear(); cin.sync();
	if (match) {
		cout << "Entered item_Sku matches!!\n";
		cout << "Are you sure want to change this item?\n";
		cout << "\n------------------------------------------------------------------------------------\n";
		cout << "Item_sku" << setw(20) << "Description" << setw(30) << "Price\t" << setw(20) << "Quantity\n";
		ItemList[index].printItem();
		cout << "If yes,Press \"Enter\" ";
		cin.getline(choice, 5); cin.clear(); cin.sync();
		if (choice[0] == '\0') {
			if (_item_sku[0] != '\0') {
				ItemList[index].setItem_sku(_item_sku);
			}
			if (_description[0] != '\0') {
				ItemList[index].setDescription(_description);
			}
			if (_price[0] != '\0') {
				ItemList[index].setPrice(atoi(_price));
			}
			if (_avaliableQuantity[0] != '\0') {
				ItemList[index].setAvailableQuantity(atoi(_avaliableQuantity));
			}
			if (_creationDate[0] != '\0') {
				ItemList[index].setCreationDate(_creationDate);
			}
			Item* temp = new Item[Item::itemCount];
			for (int i = 0; i < Item::itemCount; i++) {
				temp[i] = ItemList[i];
			}
		
			ItemList = temp;
			temp = nullptr;
			feedItemToFile();
			
			cout << "Item Information Successfully Changed and Saved!\n";
		}
	}
	else
		cout << "Wrong \"item_sku\"  was entered\n";
}
void Item::searchItem() {
	bool match = false, enter = true;
	char _item_sku[100], _description[1000], _creationDate[20];
	char _price[100], _avaliableQuantity[100];
	int count = helper::countLine("Items.txt"),itemcount=0;
	int* index = new int[count+1];
	cin.ignore();
	cout << "Please spacify at least one of the following to find the item. Leave all the feilds blank to return to Items Menue:\n";
	cout << "Item_sku: ";
	cin.getline(_item_sku, 100); cout << endl; cin.clear(); cin.sync();
	cout << "Description:";
	cin.getline(_description, 100); cout << endl; cin.clear(); cin.sync();
	cout << "Price";
	cin.getline(_price, 100); cout << endl; cin.clear(); cin.sync();
	cout << "Available Quantity:";
	cin.getline(_avaliableQuantity, 100); cout << endl; cin.clear(); cin.sync();
	cout << "Creation date:";
	cin.getline(_creationDate, 20);  cout << endl; cin.clear(); cin.sync();
	bool search = false;
	for (int i = 0; i < count; i++) {
		bool found = false, sku = true, des = true, price = true, quantity = true, date = true;
		if (_item_sku[0] != '\0') {
			if (helper::mystrcmp(_item_sku, ItemList[i].getItem_sku()) == true) {
				sku = true;
			}
			else sku = false;
		}
		if (_description[0] != '\0') {
			if (helper::mystrcmp(_description, ItemList[i].description) && sku == true) {
				des = true;
			}
			else { des = false; }
		}if (_price[0] != '\0') {
			if (atoi(_price) == ItemList[i].price && des != false) {
			   price = true;
			}
			else { price = false; }
		}if (_avaliableQuantity[0] != '\0') {
			if (atoi(_avaliableQuantity) == ItemList[i].availableQuantity && price != false) {
				quantity = true;

			}
			else { quantity = false; }
		}if (_creationDate[0] != '\0') {
			if (helper::mystrcmp(_creationDate, ItemList[i].creationDate) && quantity != false) {
				date = true;
			}
			else {
				date = false;
			}
		}
		if (sku == true && des == true && price == true && quantity == true && date == true) {
			index[itemcount] = i;
			itemcount++;
			search = true;
		}
	}
	if (search) {
		cout << "\n------------------------------------------------------------------------------------\n";
		cout << "Item_sku" << setw(20) << "Description" << setw(30) << "Price\t" << setw(20) << "Quantity\n";
		for (int i = 0; i < itemcount; i++) {
			ItemList[index[i]].printItem();
		}
	}

	else if (!search) {
		cout << "The Entered Item Doesnot Exists!";
		cout << endl << endl;
	}

}
void Item::printItem() {

	cout << item_sku << "\t\t" << setw(20) << description << setw(22) << price << setw(20) << "\t" << availableQuantity << setw(20) << "\n";
}
void Item::printItemList() {
	cout << "\n------------------------------------------------------------------------------------\n";
	cout << "Item_sku" << setw(20) << "Description" << setw(30) << "Price\t" << setw(20) << "Quantity\n";
	for (int i = 0; i < Item::itemCount; i++) {
		cout << ItemList[i].item_sku << "\t\t" << setw(20) << ItemList[i].description << setw(22) << ItemList[i].price << setw(20) << "\t" << ItemList[i].availableQuantity << setw(20) << "\n";

	}
}
Item* Item::searchSku(char* buffer,int&_index) {
	bool match = false;
	int index;
	for (int i = 0; i < Item::itemCount && match == false; i++) {
		if (helper::mystrcmp(buffer, ItemList[i].item_sku)) {
			match = true;
			index = i;
		}
	}
	if (match) {
		_index = index;
		return &ItemList[index];
		
	}
	else return NULL;
}
Item::~Item() {
	if (item_sku != nullptr) {
		delete[] item_sku;
	}
	if (description != nullptr) {
		delete[] description;
	}
	if (creationDate != nullptr) {
		delete[]creationDate;
	}
}
SilverCustomer::SilverCustomer() {
	Customer::Customer();
}
SilverCustomer::SilverCustomer(char* c, char* n, char* a, char* p, char* e, int t, int am) :Customer(c, n, a, p, e, t, am) {
	salesLimit = 40000;
}
SilverCustomer& SilverCustomer:: operator=(SilverCustomer& obj) {
	Customer::operator=(obj);
	salesLimit = 40000;
	return *this;
}
void SilverCustomer::setsalesLimit() {
	salesLimit = 40000;
}
int SilverCustomer::getsalesLimit() {
	return salesLimit;
}
SilverCustomer::~SilverCustomer() {}
GoldCustomer::GoldCustomer() {
	Customer::Customer();
	discount = 0;
}
GoldCustomer::GoldCustomer(char* c, char* n, char* a, char* p, char* e, int t, int am) :Customer(c, n, a, p, e, t, am) {
	salesLimit = 100000;
	discount = 3;

}
GoldCustomer& GoldCustomer::operator=(GoldCustomer& obj) {
	Customer::operator=(obj);
	discount = 3;
	salesLimit = 100000;
	return *this;
}
void GoldCustomer::setsalesLimit() {
	salesLimit = 100000;
}
int GoldCustomer::getsalesLimit() {
	return salesLimit;
}
GoldCustomer::~GoldCustomer() {}
PlatinumCustomer::PlatinumCustomer() {
	Customer::Customer();
	discount = 0;
}
PlatinumCustomer::PlatinumCustomer(char* c, char* n, char* a, char* p, char* e, int t, int am) :Customer(c, n, a, p, e, t, am) {
	salesLimit = 250000;
	discount = 5;
}
PlatinumCustomer& PlatinumCustomer:: operator=(PlatinumCustomer& obj) {
	Customer::operator=(obj);
	discount = 5;
	salesLimit = 250000;
	return *this;

}
void PlatinumCustomer::setsalesLimit() {
	salesLimit = 250000;

}
int  PlatinumCustomer::getsalesLimit() {
	return salesLimit;
}
PlatinumCustomer::~PlatinumCustomer() {}
Customer::Customer() {
	cnic = nullptr;
	name = nullptr;
	address = nullptr;
	phone = nullptr;
	email = nullptr;
	type = 0;
	amountPayable = 0;
	salesLimit = 0;
}
Customer::Customer(char* c, char* n, char* a, char* p, char* e, int t, int am) {
	setCnic(c);
	setAddress(a);
	setEmail(e);
	setAmountPayable(am);
	setName(n);
	setsalesLimit(0);
	setType(t);
	setPhone(p);
}
Customer::Customer(Customer& obj) {
	Customer temp;
	temp.setCnic(obj.cnic);
	temp.setAddress(obj.address);
	temp.setName(obj.name);
	temp.setEmail(obj.email);
	temp.setPhone(obj.phone);
	temp.setsalesLimit(obj.salesLimit);
	temp.setType(obj.type);
	temp.setAmountPayable(obj.amountPayable);

}
Customer& Customer::operator=(Customer& obj) {
	this->setCnic(obj.cnic);
	this->setAddress(obj.address);
	this->setName(obj.name);
	this->setEmail(obj.email);
	this->setPhone(obj.phone);
	this->setsalesLimit(obj.salesLimit);
	this->setType(obj.type);
	this->setAmountPayable(obj.amountPayable);
	return *this;
}
char* Customer::getCnic() {
	return cnic;
}
char* Customer::getName() {
	return name;
}
char* Customer::getAddress() {
	return address;
}
char* Customer::getPhone() {
	return phone;
}
char* Customer::getEmail() {
	return email;
}
int Customer::getType() {
	return type;
}
int Customer::getAmountPayable() {
	return amountPayable;

}
int Customer::getsalesLimit() {
	return salesLimit;
}
void Customer::setsalesLimit(int x) {
	salesLimit = x;
}
void Customer::setCnic(char* _cnic) {
	cnic = new char[helper::mystrlen(_cnic)+1];
	helper::mystrcpy(cnic, _cnic);
}
void Customer::setName(char* _name) {
	name = new char[helper::mystrlen(_name)+1];
	helper::mystrcpy(name, _name);

}
void Customer::setAddress(char* _address) {
	address = new char[helper::mystrlen(_address)+1];
	helper::mystrcpy(address, _address);
}
void Customer::setPhone(char* _phone) {
	phone = new char[helper::mystrlen(_phone)+1];
	helper::mystrcpy(phone, _phone);
}
void Customer::setEmail(char* _email) {
	email = new char[helper::mystrlen(_email)+1];
	helper::mystrcpy(email, _email);
}
void Customer::setType(int _type) {
	type = _type;

}
void Customer::setAmountPayable(int _amountPayable) {
	amountPayable = _amountPayable;

}
void Customer::addCustomer() {
	bool righttype = false;
	char _cnic[20], _name[50], _address[100], _phone[15], _email[50],type[10];
	int _type, _amountPayable, row;
	cin.ignore();
	cout << "Enter the data of Customer: \n";
	cout << " Cnic : ";
	cin.getline(_cnic, 20); cout << endl; cin.clear(); cin.sync();
	cout << " Name: ";
	cin.getline(_name, 50); cout << endl; cin.clear(); cin.sync();
	cout << " Address: ";
	cin.getline(_address, 100); cout << endl; cin.clear(); cin.sync();
	cout << " Phone: ";
	cin.getline(_phone, 15); cout << endl; cin.clear(); cin.sync();
	cout << " Email: ";
	cin.getline(_email, 50); cout << endl; cin.clear(); cin.sync();
	while (righttype == false) {
		cout << "Enter '1' for Silver Customer, '2' for Gold Customer, '3' for Platinum Customer.\n";
		cout << " Type: ";
		cin.getline(type, 10); cout << endl; cin.clear(); cin.sync();
		_type = atoi(type);
		if (_type == 1 || _type == 2 || _type == 3) {
			righttype = true;
		}
		else cout << "wrong type entred!\n";

	}
	_amountPayable=0;
	Customer* obj;
	if (_type == 1) {
		obj = new SilverCustomer(_cnic, _name, _address, _phone, _email, _type, _amountPayable);
	}
	else if (_type == 2) {
		obj = new GoldCustomer(_cnic, _name, _address, _phone, _email, _type, _amountPayable);
	}
	else obj = new PlatinumCustomer(_cnic, _name, _address, _phone, _email, _type, _amountPayable);
	if (Customer::customerCount != 0) {
		Customer** temp = new Customer * [Customer::customerCount + 1];
		for (int i = 0; i < Customer::customerCount; i++) {
			if (CustomerList[i]->type == 1) {
				temp[i] = new SilverCustomer;
				temp[i] = CustomerList[i];
			


			}
			else if (CustomerList[i]->type == 2) {
				temp[i] = CustomerList[i];
			}
			else { temp[i] = CustomerList[i]; }
		}
		temp[Customer::customerCount] = obj;
		row = Customer::customerCount;
		


		CustomerList = temp;
	}
	else {
		row = 0;
		CustomerList = new Customer * (obj);
	}

	fstream Customerfile("Customers.txt", ios::app);
	if (Customerfile.is_open()) {
		Customerfile << CustomerList[row]->cnic;
		Customerfile << ';';
		Customerfile << CustomerList[row]->name;
		Customerfile << ';';
		Customerfile << CustomerList[row]->address;
		Customerfile << ';';
		Customerfile << CustomerList[row]->phone;
		Customerfile << ';';
		Customerfile << CustomerList[row]->email;
		Customerfile << ';';
		Customerfile << CustomerList[row]->type;
		Customerfile << ';';
		Customerfile << CustomerList[row]->amountPayable;
		Customerfile << ';';
		Customerfile << CustomerList[row]->salesLimit;
		Customerfile << '\n';
		Customer::customerCount++;
		Customerfile.close();
		cout << "New Customer Has Been Successfully Added" << endl << endl;
	}
}
void Customer::readCustomers() {
	fstream customerfile("Customers.txt");
	char _cnic[20], _name[50], _address[100], _phone[15], _email[50];
	int _type, _amountPayable, _salesLimit;

	if (Customer::customerCount == 0) {
		CustomerList = nullptr;
	}
	else {
		CustomerList = new Customer * [Customer::customerCount];
		for (int i = 0; i < Customer::customerCount; i++) {
			customerfile.getline(_cnic, 20, ';');
			customerfile.getline(_name, 100, ';');
			customerfile.getline(_address, 100, ';');
			customerfile.getline(_phone, 100, ';');
			customerfile.getline(_email, 100, ';');
			customerfile >> _type;
			customerfile.ignore(1, ';');
			customerfile >> _amountPayable;
			customerfile.ignore(1, ';');
			customerfile >> _salesLimit;
			customerfile.ignore(1, '\n');
			if (_type == 1) {
				CustomerList[i] = new SilverCustomer(_cnic, _name, _address, _phone, _email, _type, _amountPayable);
			}
			else if (_type == 2) {
				CustomerList[i] = new GoldCustomer(_cnic, _name, _address, _phone, _email, _type, _amountPayable);
			}
			else CustomerList[i] = new PlatinumCustomer(_cnic, _name, _address, _phone, _email, _type, _amountPayable);

		}
	}
	customerfile.close();
}
void Customer::searchCustomer() {
	bool match = false, enter = true;
	char _cnic[20], _name[20], _address[100], _phone[15], _email[20];
	char  _type[2];
	int count = helper::countLine("Customers.txt"),customercount=0;
	int* index = new int[count + 1];
	cin.ignore();
	cout << "Please spacify at least one of the following to find the customer. Leave all the feilds blank to return to customers Menue:\n";
	cout << " Cnic ";
	cin.getline(_cnic, 100); cout << endl; cin.clear(); cin.sync();
	cout << " Name:";
	cin.getline(_name, 100); cout << endl; cin.clear(); cin.sync();
	cout << " Address";
	cin.getline(_address, 100); cout << endl; cin.clear(); cin.sync();
	cout << " Phone:";
	cin.getline(_phone, 100); cout << endl; cin.clear(); cin.sync();
	cout << " Email:";
	cin.getline(_email, 20);  cout << endl; cin.clear(); cin.sync();
	cout << " Type:";
	cin.getline(_type, 20);  cout << endl; cin.clear(); cin.sync();
	bool search = false;
	for (int i = 0; i < count; i++) {
		bool found = false, c = true, n = true, p = true, e = true, t = true;
		if (_cnic[0] != '\0') {
			if (helper::mystrcmp(_cnic, CustomerList[i]->cnic)) {
				c = true;
			}
			else {  c = false; }
		}if (_name[0] != '\0') {
			if (helper::mystrcmp(_name, CustomerList[i]->name) && c != false) {
				n = true;
			}
			else {  n = false; }
		}
		if (_phone[0] != '\0') {
			if (helper::mystrcmp(_phone, CustomerList[i]->phone) && n != false) {
				p = true;
			}
			else {p = false; }
		}

		if (_email[0] != '\0') {
			if (helper::mystrcmp(_email, CustomerList[i]->email) && p != false) {
				e= true;
			}
			else {  e = false; }
		}

		if (_type[0] != '\0') {
			if (atoi(_type) == CustomerList[i]->type && e != false) {
				t = true;
			}
			else { t = true; }
		}


		if (c == true&&n == true&& p == true&&e == true&& t == true) {
			
			index[customercount] = i;
			customercount++;
			search = true;
		}
	}

	if (search) {
		cout << "---------------------------------------------------------------------------------------------------------\n";
		cout << "CNIC" << setw(20) << "Name" << setw(20) << "Email" << setw(20) << "Phone" << setw(20) << "SalesLimit" << endl;
		cout << "--------------------------------------------------------------------------------------------------------\n";
		for (int i = 0; i < customercount; i++) {
			CustomerList[index[i]]->printCustomer();
		}

	}

	else if (!search) {
		cout << "The Entered Item Doesnot Exists!";
		cout << endl;
		cout << endl;
	}

}
void Customer::modifyCustomer() {
	char buffer[30];
	bool match = false,righttype=false;
	int index = 0;
	char _cnic[20], _name[20], _address[100], _phone[15], _email[30];
	char  _type[2], _amountPayable[100], choice[5];
	cin.ignore();
	cout << "enter the \"Cnic\" of the item you want to change:";
	cin.getline(buffer, 30); cin.clear(); cin.sync(); cout << endl;
	for (int i = 0; i < Customer::customerCount && match == false; i++) {
		if (helper::mystrcmp(buffer, CustomerList[i]->cnic)) {
			match = true;
			index = i;
		}
	}
	cout << "Enter customer Details Which You Want to Change:\n";
	cout << " Cnic ";
	cin.getline(_cnic, 20); cout << endl; cin.clear(); cin.sync();
	cout << " Name:";
	cin.getline(_name, 20); cout << endl; cin.clear(); cin.sync();
	cout << " Address";
	cin.getline(_address, 100); cout << endl; cin.clear(); cin.sync();
	cout << " Phone:";
	cin.getline(_phone, 15); cout << endl; cin.clear(); cin.sync();
	cout << " Email:";
	cin.getline(_email, 30);  cout << endl; cin.clear(); cin.sync();
	while (righttype == false) {
		cout << "Enter '1' for Silver Customer, '2' for Gold Customer, '3' for Platinum Customer.\n";
		cout << " Type: ";
		cin.getline(_type, 10); cout << endl; cin.clear(); cin.sync();
		if (atoi(_type) == 1 || atoi(_type) == 2 || atoi(_type) == 3||_type[0]=='\0') {
			righttype = true;
		}
		else cout << "wrong type entred!\n";

	}
	cout << "Amount PayAble";
	cin.getline(_amountPayable, 20);  cout << endl; cin.clear(); cin.sync();

	if (match) {
		cout << "Entered Cnic matches!!\n";
		cout << "Are you sure want to change this customer?\n";
		//customerList[index][0].printItem();
		cout << "If yes,Press \"Enter\" ";
		cin.getline(choice, 5); cin.clear(); cin.sync();
		if (choice[0] == '\0') {
			if (_cnic[0] != '\0') {
				CustomerList[index]->setCnic(_cnic);
			}
			if (_name[0] != '\0') {
				CustomerList[index]->setName(_name);
			}
			if (_address[0] != '\0') {
				CustomerList[index]->setAddress(_address);
			}
			if (_email[0] != '\0') {
				CustomerList[index]->setEmail(_email);
			}
			if (_type[0] != '\0') {
				CustomerList[index]->setType(atoi(_type));
				if (atoi(_type) == 1) {
					CustomerList[index]->setsalesLimit(40000);
				}
				else if (atoi(_type) == 2) {
					CustomerList[index]->setsalesLimit(100000);
				}
				else if (atoi(_type) == 3) {
					CustomerList[index]->setsalesLimit(250000);
				}
			}

			if (_amountPayable[0] != '\0') {
				CustomerList[index]->setType(atoi(_amountPayable));
				
			}

			Customer** temp = new Customer * [Customer::customerCount + 1];
			for (int i = 0; i < Customer::customerCount; i++) {
				if (CustomerList[i]->type == 1) {
					temp[i] = CustomerList[i];
				}
				else if (CustomerList[i]->type == 2) {
					temp[i] = CustomerList[i];
				}
				else { temp[i] = CustomerList[i]; }

			}
			feedCustomerToFile();
			
			cout << "Customer Information Successfully Changed and Saved!\n";
		}
	}
	else
		cout << "Wrong \"Cnic\"  was entered\n";
}
void Customer::deleteCustomer() {
	char buffer[30];
	bool match = false;
	int index = 0;
	cin.ignore();
	cout << "enter the \"cnic\" of the customer you want to delete:";
	cin.getline(buffer, 30); cout << endl; cin.clear(); cin.sync();
	cout << endl;
	char choice[5];
	for (int i = 0; i < Customer::customerCount && match == false; i++) {
		if (helper::mystrcmp(buffer, CustomerList[i]->cnic)) {
			match = true;
			index = i;
		}
	}  //if this item is included in any current sale it should notb be removed
	if (match) {
		if (Sales::CnicExistInSale(buffer) == true) {
			cout << "The Customer is Associtaed with respective sale hence cant be deleted\n";
		}
		else {
			cout << "Entered Cnic matches!!\n";
			cout << "Are you sure want to delete this customer?\n";
			CustomerList[index]->printCustomer();
			cout << "If yes,Press \"Enter\" ";
			cin.get(choice, 5); cout << endl; cin.clear(); cin.sync();
			if (choice[0] == '\0') {
				Customer::customerCount--;
				Customer** temp = new Customer * [Customer::customerCount];
				for (int i = 0, j = 0; i < Customer::customerCount; i++, j++) {
					if (j == index) {
						temp[i] = CustomerList[j + 1];
						j++;
					}
					else temp[i] = CustomerList[j];

				}int count = 0;

				CustomerList = temp;
				feedCustomerToFile();
				cout << "Customer Has Been Successfully Deleted" << endl << endl;



			}
		}

	}
	else
		cout << "Wrong \"Cnic\"  was entered\n";

}
void Customer::feedCustomerToFile() {
	fstream Customerfile("Customers.txt");
	ofstream tempfile("temp.txt");
	if (Customerfile.is_open() && tempfile.is_open())
	{
		int i = 0;
		while (i < Customer::customerCount)
		{
			tempfile << CustomerList[i]->cnic;
			tempfile << ';';
			tempfile << CustomerList[i]->name;
			tempfile << ';';
			tempfile << CustomerList[i]->address;
			tempfile << ';';
			tempfile << CustomerList[i]->phone;
			tempfile << ';';
			tempfile << CustomerList[i]->email;
			tempfile << ';';
			tempfile << CustomerList[i]->type;
			tempfile << ';';
			tempfile << CustomerList[i]->amountPayable;
			tempfile << ';';
			tempfile << CustomerList[i]->salesLimit;
			tempfile << '\n';
			i++;
		}
		tempfile.close();
		Customerfile.close();
		remove("Customers.txt");
		int k = rename("temp.txt", "Customers.txt");
	}

}
void Customer::printCustomer() {
	cout << setw(15)<<this->cnic << setw(15) << this->name << "\t\t"<< this->email << setw(15) << this->phone << setw(15) << this->salesLimit << endl;
}
Customer* Customer::searchCnic(char* buffer,int&_index) {
	int index;
	bool match = false;
	for (int i = 0; i < Customer::customerCount && match == false; i++) {
		if (helper::mystrcmp(buffer, CustomerList[i]->cnic)) {
			match = true;
			index = i;
		}
	}
	if (match==true) {
		_index = index;
		return CustomerList[index];
		
	}
	else return NULL;

}
Customer::~Customer() {
	if (cnic != nullptr) {
		delete[] cnic;
	}
	if (name != nullptr) {
		delete[] name;
	}
	if (address != nullptr) {
		delete[] address;
	}
	if (phone != nullptr) {
		delete[] phone;
	}
	if (email != nullptr) {
		delete[] email;
	}
}
//sales class
Sales::Sales() {
	c = nullptr;
	date=nullptr;
	status = nullptr;
	salesId = 0;
	SalesAmount = 0;
}
Sales::Sales(char*_cnic, char* d,char*s,int x,int a) {
	c->setCnic(_cnic);
	setDate(d);
	setStatus(s);
	setSalesId(x);
	setSalesAmount(a);
}
Sales::Sales( Sales&obj) {
	Sales temp;
	temp.setDate(obj.date);
	temp.c = obj.c;
	temp.setStatus(obj.getStatus());
	temp.setSalesAmount(obj.getSalesAmount());
}
Sales& Sales:: operator= ( Sales& obj) {
	this->setDate(obj.date);
	this->c = obj.c;
	this->setStatus(obj.getStatus());
	this->setSalesId(obj.salesId);
	this->setSalesAmount(obj.getSalesAmount());
	return *this;

}
int Sales::get_ID() {
	return _id;
 }
void  Sales::set_ID(int x) {
	_id = x;

 }
int Sales::getSalesId() {
	return salesId;
}
int Sales::get_lineNo() {
	return _lineNo;
}
void Sales::setDate(char*d) {
	date = new char[helper::mystrlen(d) + 1];
	helper::mystrcpy(date, d);
}
void Sales::setSalesAmount(int x) {
	SalesAmount=x;
}
int Sales::getSalesAmount() {
	return  SalesAmount;
}
char* Sales::getDate() {
	return date;

}
void Sales::setStatus(char*s) {
	status = new char[helper::mystrlen(s) + 1];
	helper::mystrcpy(status, s);
}
char* Sales::getStatus(){
	return status;
}
char* Sales::getCustomerName() {
	return c->getName();
}
char* Sales::getCustomerCnic() {
	return c->getCnic();

}
void Sales::setSalesId(int x) {
	salesId = x;
}
int Sales::CheckSales_Id(int buff) {
	bool match = false;
	int index=0;
	for (int i = 0; i <salescount&&match==false; i++) {
	
		if (buff == salesList[i].getSalesId()) {
			match = true;
			index = i;

		}

	}if (match == true) {
		return index;
	}
	else return -1;

}
int*  Sales::checkSalesDate(char* date,char*cnic,int& count) {
	count = 0;
	bool match = false;
	int *index=new int[salescount];
	for (int i = 0,j=0; i < salescount; i++) {
		if (helper::mystrcmp(salesList[i].getDate(), date)&& helper::mystrcmp(salesList[i].c->getCnic(), cnic)) {
			match = true;
			index[j] = i;
			count++;
			j++;
		}
	}if (match == true) {
		return index;
	}
	else return nullptr;

}
bool Sales::check_ItemSku(char* buffer) {
	bool match = false;
	for (int i = 0; i < Sales::salesLineItemcount&&match==false;i++) {
		if (helper::mystrcmp(salelineList[i].getItemOfSale_sku(), buffer)) {
			match = true;
		}

	}
	if (match == true) {
		return true;
	}
	else return false;

}
Customer* Sales::checkCnic(char* buffer,int&_index) {
	Customer a;
	c = a.searchCnic(buffer,_index);
	return c;


}
int Sales::searchSalesId(int buff) {
	int index;
	bool match = false;
	for (int i = 0; i <= salescount&&match==false; i++) {
		if (buff == salesList[i].salesId) {
			match = true;
			index = i;

		}
	}
	if (match == true) {
		return index;
	}
	else return -1;
}
void Sales::AddSalesLineitem(char** Item_sku,int* quantity,int Id,int lineNo,int itemcount){
	Item t;
	int _index;
		int count=Sales::salesLineItemcount;
		if (count!= 0) {
			SalesLineItem *temp = new SalesLineItem[count+itemcount];
			_index = Sales::searchSalesId(Id);
			for (int i = 0; i < count; i++) {
				temp[i] = salelineList[i];      //already existing items
				
			}
			for (int i = 0; i < itemcount; i++) {
				temp[i].setLineNo(_lineNo);
				temp[i].saleid = Sales::salesList[_index];       //newly added items
				temp[i].setItemOfSale_sku(Item_sku[i]);
				temp[i].setQuantity(quantity[i]);
				t = *t.searchSku(Item_sku[i],_index);
				Item::ItemList[_index].setAvailableQuantity(t.getAvailableQuantity() - quantity[i]);
				Item::feedItemToFile();
				Sales::_lineNo++;
				

			}
			delete[] salelineList;
			salelineList = temp;
			temp = nullptr;

		}
		else {
			salelineList = new SalesLineItem[itemcount];
			for (int i = 0; i < itemcount; i++) {
				salelineList[i].setLineNo(_lineNo);
				salelineList[i].setItemOfSale_Id(Id);
				salelineList[i].setItemOfSale_sku(Item_sku[i]);
				salelineList[i].setQuantity(quantity[i]);
				t = *t.searchSku(Item_sku[i],_index);
				Item::ItemList[_index].setAvailableQuantity(t.getAvailableQuantity() - quantity[i]);
				Item::feedItemToFile();
				Sales::_lineNo++;
				
			}
			
		}

	    fstream fin("SalesLine.txt", ios::app);
		if (fin.is_open()) {
			int j = 0;
			while (j < itemcount) {
				fin << salelineList[j].getLineNo();
				fin << ';';
				fin << Id;
				fin << ';';
				fin << salelineList[j].getItemOfSale_sku();
				fin << ';';
				fin << salelineList[j].getQuantity();
				fin << '\n';
				j++;
				salesLineItemcount++;
			}
			
			
			fin.close();
		}
}
void Sales::readSalesLineItem() {

	fstream fin("SalesLine.txt");
	char buffer[100];
	int x,index=0;
	if (salesLineItemcount == 0) {
		salelineList = nullptr;
		
	}
	else
	{
		salelineList = new SalesLineItem[salesLineItemcount];
		for (int i = 0; i < salesLineItemcount; i++) {
			fin >> x;
			salelineList[i].setLineNo(x);
			fin.ignore(1, ';');
			fin >> x;
			index=Sales::searchSalesId(x);
			salelineList[i].saleid = salesList[index];
			fin.ignore(1, ';');
			fin.getline(buffer, 20, ';');
			salelineList[i].setItemOfSale_sku(buffer);
			fin >> x;
			salelineList[i].setQuantity(x);
			fin.ignore(1, '\n');
			
			Sales::_lineNo++;
		}
		fin.close();
	}
	
 }
void Sales::writeSales(char* _cnic, char* date,  char* s, int Id,int cindex,int salesAmount) {
	int count = salescount;
	
	if (count != 0) {
		Sales* temp = new Sales[count + 1];
		for (int i = 0; i < count; i++) {
			temp[i] = salesList[i];
		}
		temp[count].c = Customer::CustomerList[cindex];
		temp[count].setDate(date);
		temp[count].setStatus(s);
		temp[count].setSalesId(Id);
		temp[count].setSalesAmount(salesAmount);
		delete[] salesList;
		salesList = temp;
		temp = nullptr;

	}
	else {
		salesList = new Sales[count+1];
		salesList[count].c= Customer::CustomerList[cindex];
		salesList[count].setDate(date);
		salesList[count].setStatus(s);
		salesList[count].setSalesId(Id);
		salesList[count].setSalesAmount(salesAmount);

	}
	fstream fin("Sales.txt",ios::app);
	if (fin.is_open()) {
		fin << salesList[count].salesId;
		fin << ';';
		fin << salesList[count].c->getCnic();
		fin << ';';
		fin << salesList[count].getDate();
		fin << ';';
		fin << salesList[count].getSalesAmount();
		fin << ';';
		fin << salesList[count].getStatus();
		fin << '\n';
		Sales::salescount++;
		fin.close();
	}
}
void Sales::readSales() {
	fstream fin("Sales.txt");
	char buffer[100];
	int x,index=-1;
	if (Sales::salescount == 0) {
		salesList = nullptr;
		//Sales::_id++;
	}
	else
	{
		salesList = new Sales[Sales::salescount];
		for (int i = 0; i < Sales::salescount; i++) {
			fin>>x;
			salesList[i].setSalesId(x);
			fin.ignore(1, ';');
			fin.getline(buffer, 30, ';');
			salesList[i].c->searchCnic(buffer,index);
			salesList[i].c = Customer::CustomerList[index];
			fin.getline(buffer, 15, ';');
			salesList[i].setDate(buffer);
			fin >> x;
			salesList[i].setSalesAmount(x);
			fin.ignore(1, ';');
			fin.getline(buffer, 20,'\n');
			salesList[i].setStatus(buffer);

			Sales::_id++;


		}
		fin.close();
	}
	
 }
bool Sales::CnicExistInSale(char* buffer) {
	bool match = false;
	for (int i = 0; i < salescount&&match==false; i++) {
		if (helper::mystrcmp(salesList[i].getCustomerCnic(), buffer)) {
			match = true;
		}
	}
	if (match == true) {
		return true;
	}
	else return false;

}
void Sales::FeedSalesToFile() {
	fstream salesfile("Sales.txt");
	ofstream tempfile("temp.txt");
	if (salesfile.is_open() && tempfile.is_open())
	{
		int i = 0;
		while (i < salescount)
		{
			tempfile << salesList[i].salesId;
			tempfile << ';';
			tempfile << salesList[i].getCustomerCnic();
			tempfile << ';';
			tempfile << salesList[i].date;
			tempfile << ';';
			tempfile << salesList[i].SalesAmount;
			tempfile << ';';
			tempfile << salesList[i].status;
			tempfile << '\n';
			i++;
		}
		tempfile.close();
		salesfile.close();
		remove("Sales.txt");
		int k = rename("temp.txt", "Sales.txt");
	}
}
Sales::~Sales() {
	
	delete[] date;
	delete[]status;
}
//sales line item class
SalesLineItem::SalesLineItem() {
	 lineNo=0;
	itemOfSale=nullptr;
	Quantity=0;
}
SalesLineItem::SalesLineItem(int c, int i, char* s, int q) {
	lineNo = c;
	saleid.setSalesId(i);
	setItemOfSale_sku(s);
	Quantity = q;
}
 SalesLineItem::SalesLineItem( SalesLineItem&obj) {
	 SalesLineItem temp;
	 temp.saleid=obj.saleid;
	 temp.setItemOfSale_sku(obj.getItemOfSale_sku());
	 temp.setLineNo(obj.getLineNo());
	 temp.setQuantity(obj.getQuantity());

}
SalesLineItem& SalesLineItem::operator=(SalesLineItem& obj) {
	
	this->saleid = obj.saleid;
	this->setItemOfSale_sku(obj.getItemOfSale_sku());
	this->setLineNo(obj.getLineNo());
	this->setQuantity(obj.getQuantity());
	return *this;
}
void  SalesLineItem::setQuantity(int x) {
	Quantity = x;

}
int SalesLineItem::getQuantity() {
	return Quantity;
}
char*SalesLineItem::getItemOfSale_sku() {
	return itemOfSale;
}
void SalesLineItem::setItemOfSale_sku(char*s) {
	int size = helper::mystrlen(s);
	itemOfSale = new char[size+1];
	helper::mystrcpy(itemOfSale, s);

}
void SalesLineItem::setItemOfSale_Id(int x) {
     this->saleid =Sales::salesList[x];
}
int SalesLineItem::getItemOfSale_Id() {
	return saleid.getSalesId();
}
void SalesLineItem::setLineNo(int x) {
	lineNo = x;
}
int SalesLineItem::getLineNo() {
	return lineNo;
}
SalesLineItem::~SalesLineItem() {
	if (itemOfSale != nullptr) {
		delete[] itemOfSale;
	}
}

//receipt class
Receipt::Receipt() {
	receiptNo=0;
	receiptDate=nullptr;
	 amount=0;
}
Receipt::Receipt(Receipt&obj) {
	Receipt temp;
	temp.setamount(obj.amount);
	temp.setReceiptDate(obj.receiptDate);
	temp.setReceiptNo(obj.receiptNo);
	temp.setReceiptSaleId(obj.getReceiptSaleId());

}
Receipt& Receipt::operator=(Receipt&obj) {
	this->setamount(obj.amount);
	this->setReceiptDate(obj.receiptDate);
	this->setReceiptNo(obj.receiptNo);
	this->setReceiptSaleId(obj.getReceiptSaleId());
	return *this;
}
int Receipt::getReceiptNo() {
	return  receiptNo;
 }
void Receipt::setReceiptNo(int x) {
	receiptNo = x;

}
void Receipt::setamount(int x) {
	amount = x;

}
int Receipt::getamount() {
	return amount;
}
void  Receipt::setReceiptDate(char*_date) {
	receiptDate = new char[helper::mystrlen(_date) + 1];
	helper::mystrcpy(receiptDate, _date);

}
char* Receipt::getReceiptdate() {
	return receiptDate;
}
void Receipt::setReceiptSaleId(int x) {
	int index = 0;
	index = Sales::searchSalesId(x);
	receiptSaleId = Sales::salesList[index];

}
int Receipt::getReceiptSaleId() {
	return receiptSaleId.getSalesId();
}
void Receipt::readReceipt() {
	fstream fin("Receipt.txt");
	char buffer[100];
	int x,index=0;
	if (receiptCount == 0) {
		receiptList = nullptr;
	}
	else {
		receiptList = new Receipt[receiptCount];
		for (int i = 0; i < receiptCount; i++) {
			fin >> x;
			receiptList[i].setReceiptNo(x);
			fin.ignore(1, ';');
			fin.getline(buffer, 20, ';');
			receiptList[i].setReceiptDate(buffer);
			fin >> x;
			index=Sales::searchSalesId(x);
			receiptList[i].receiptSaleId = Sales::salesList[index];
			fin.ignore(1, ';');
			fin >> x;
			receiptList[i].setamount(x);
			fin.ignore(1, '\n');
			
			_rno++;
		}
		
	}
	fin.close();
}
int* Receipt::checkSalesId_inReceipts(int buff, int &indexCount) {
	bool match = false;
	
	if (receiptCount != 0) {
		int* indexArr = new int[receiptCount];
		int j = 0;
		for (int i = 0; i < receiptCount; i++) {
			if (buff = receiptList[i].receiptSaleId.getSalesId()) {
				indexArr[j++] = i;
				indexCount++;
				match = true;
			}
		}
		if (match == true) {
			return indexArr;
		}
		else return nullptr;
	}
	else return nullptr;
	

 }
 int Receipt::get_rno() {
	 return _rno;
}
 void Receipt::set_rno(int x) {
	 _rno = x;

 }
 void Receipt::writeReceipt(char*_date, int Rno, int sales_IdIndex, int amount) {
	 int count = receiptCount;
	 if (receiptCount != 0) {
		 Receipt* temp = new Receipt[count + 1];
		 for (int i = 0; i < count; i++) {
			 temp[i] = receiptList[i];
		 }
		 temp[count].setReceiptNo(Rno);
		 temp[count].setReceiptDate(_date);
		 temp[count].setamount(amount);
		 temp[count].receiptSaleId = Sales::salesList[sales_IdIndex];
		 delete[] receiptList;
		 receiptList = temp;
		 temp = nullptr;
	 }
	 else {
		 receiptList = new Receipt[count + 1];
		 receiptList[count].setReceiptNo(Rno);
		 receiptList[count].setReceiptDate(_date);
		 receiptList[count].setamount(amount);
		 receiptList[count].receiptSaleId = Sales::salesList[sales_IdIndex];
	 }
	 fstream fin("Receipt.txt",ios::app);
	 if (fin.is_open()) {
		 {
			 fin << receiptList[count].getReceiptNo();
			 fin << ";";
			 fin << receiptList[count].getReceiptdate();
			 fin << ";";
			 fin << receiptList[count].getReceiptSaleId();
			 fin << ";";
			 fin << receiptList[count].getamount();
			 fin << "\n";
			 _rno++;
			 receiptCount++;
		 }
	 }
	 fin.close();

 }
 Receipt::~Receipt() {
	 if (receiptDate != nullptr){
		delete[] receiptDate;

	 }
	
 }
  